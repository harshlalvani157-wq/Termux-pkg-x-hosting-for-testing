#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/data/data/app.xodos2/files/usr/lib"
XSLT_LIBS="-lxslt -lxml2"
XSLT_PRIVATE_LIBS=" -lm"
XSLT_INCLUDEDIR="-I/data/data/app.xodos2/files/usr/include"
MODULE_VERSION="xslt-1.1.45"
