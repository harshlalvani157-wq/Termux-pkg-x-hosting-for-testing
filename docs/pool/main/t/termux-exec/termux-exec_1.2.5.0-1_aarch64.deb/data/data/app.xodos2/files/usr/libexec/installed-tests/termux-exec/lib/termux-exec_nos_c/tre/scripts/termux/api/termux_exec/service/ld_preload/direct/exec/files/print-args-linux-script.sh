#!/data/data/app.xodos2/files/usr/bin/sh

echo "$@"
