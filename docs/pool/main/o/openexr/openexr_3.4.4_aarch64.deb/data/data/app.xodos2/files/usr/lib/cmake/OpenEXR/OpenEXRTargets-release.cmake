#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "OpenEXR::openjph" for configuration "Release"
set_property(TARGET OpenEXR::openjph APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OpenEXR::openjph PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/app.xodos2/files/usr/lib/libopenjph.so"
  IMPORTED_SONAME_RELEASE "libopenjph.so"
  )

list(APPEND _cmake_import_check_targets OpenEXR::openjph )
list(APPEND _cmake_import_check_files_for_OpenEXR::openjph "/data/data/app.xodos2/files/usr/lib/libopenjph.so" )

# Import target "OpenEXR::Iex" for configuration "Release"
set_property(TARGET OpenEXR::Iex APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OpenEXR::Iex PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/app.xodos2/files/usr/lib/libIex-3_4.so"
  IMPORTED_SONAME_RELEASE "libIex-3_4.so"
  )

list(APPEND _cmake_import_check_targets OpenEXR::Iex )
list(APPEND _cmake_import_check_files_for_OpenEXR::Iex "/data/data/app.xodos2/files/usr/lib/libIex-3_4.so" )

# Import target "OpenEXR::IlmThread" for configuration "Release"
set_property(TARGET OpenEXR::IlmThread APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OpenEXR::IlmThread PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/app.xodos2/files/usr/lib/libIlmThread-3_4.so"
  IMPORTED_SONAME_RELEASE "libIlmThread-3_4.so"
  )

list(APPEND _cmake_import_check_targets OpenEXR::IlmThread )
list(APPEND _cmake_import_check_files_for_OpenEXR::IlmThread "/data/data/app.xodos2/files/usr/lib/libIlmThread-3_4.so" )

# Import target "OpenEXR::OpenEXRCore" for configuration "Release"
set_property(TARGET OpenEXR::OpenEXRCore APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OpenEXR::OpenEXRCore PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "OpenEXR::openjph"
  IMPORTED_LOCATION_RELEASE "/data/data/app.xodos2/files/usr/lib/libOpenEXRCore-3_4.so"
  IMPORTED_SONAME_RELEASE "libOpenEXRCore-3_4.so"
  )

list(APPEND _cmake_import_check_targets OpenEXR::OpenEXRCore )
list(APPEND _cmake_import_check_files_for_OpenEXR::OpenEXRCore "/data/data/app.xodos2/files/usr/lib/libOpenEXRCore-3_4.so" )

# Import target "OpenEXR::OpenEXR" for configuration "Release"
set_property(TARGET OpenEXR::OpenEXR APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OpenEXR::OpenEXR PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/app.xodos2/files/usr/lib/libOpenEXR-3_4.so"
  IMPORTED_SONAME_RELEASE "libOpenEXR-3_4.so"
  )

list(APPEND _cmake_import_check_targets OpenEXR::OpenEXR )
list(APPEND _cmake_import_check_files_for_OpenEXR::OpenEXR "/data/data/app.xodos2/files/usr/lib/libOpenEXR-3_4.so" )

# Import target "OpenEXR::OpenEXRUtil" for configuration "Release"
set_property(TARGET OpenEXR::OpenEXRUtil APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OpenEXR::OpenEXRUtil PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/app.xodos2/files/usr/lib/libOpenEXRUtil-3_4.so"
  IMPORTED_SONAME_RELEASE "libOpenEXRUtil-3_4.so"
  )

list(APPEND _cmake_import_check_targets OpenEXR::OpenEXRUtil )
list(APPEND _cmake_import_check_files_for_OpenEXR::OpenEXRUtil "/data/data/app.xodos2/files/usr/lib/libOpenEXRUtil-3_4.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
